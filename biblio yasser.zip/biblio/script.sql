CREATE DATABASE biblio;
USE biblio;
CREATE TABLE etudiant (
  cin varchar(10) NOT NULL PRIMARY KEY,
  nom varchar(30) NOT NULL,
  prenom varchar(30) NOT NULL,
  filiere varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO etudiant (cin, nom, prenom, filiere) VALUES ('A1234', 'EL QARFAD', 'Youssef', 'Génie Informatique 1'),('P3333', 'Rida', 'Yasser', 'Génie Informatique 1');

CREATE TABLE livre (
  id int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
  titre varchar(50) NOT NULL,
  numEdition int NOT NULL,
  dateApparition varchar(10) NOT NULL,
  stock int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO livre (id, titre, numEdition, dateApparition, stock) VALUES (1, 'Mostaqil', '123', '2019', 5),(2, 'YES', '322', '2019', 4);

CREATE TABLE emprunte (
  cin_etudiant varchar(10),
  id_livre int(11),
  PRIMARY KEY(cin_etudiant,id_livre),
  FOREIGN KEY (cin_etudiant) REFERENCES etudiant(cin) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (id_livre) REFERENCES livre(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


