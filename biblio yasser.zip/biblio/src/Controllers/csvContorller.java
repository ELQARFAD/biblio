package Controllers;
import Models.DB;
import Models.generated.tables.Etudiant;
import Models.generated.tables.Livre;
import Vues.CSVVue;
import Vues.vue;
import java.io.*;
import java.sql.SQLException;
import java.util.concurrent.Executors;

public class csvContorller {
    public static void loadCSV(){
        switch ( CSVVue.getTable() ){
            case 1 : loadEtudiant(); break;
            case 2 : loadLivre()   ; break;
            default: vue.NV(); loadCSV(); }
    }
    public static void saveCSV(){
        switch ( CSVVue.getTable() ){
            case 1 : saveEtudiant(); break;
            case 2 : saveLivre()   ; break;
            default: vue.NV(); saveCSV(); }
    }
    private static void loadEtudiant(){
        Executors.newSingleThreadExecutor().submit( () -> {
            try{ BufferedReader br = new BufferedReader(new FileReader(CSVVue.getLink(1))); String ligne ;
                while ((ligne = br.readLine()) != null) etudiantController.insert(ligne.split(","));
            }catch (IOException ex) { vue.printe("Erreur de fichier"); } catch (Exception e) { vue.printe("Erreur de connection."); }
        });
    }
    private static void loadLivre(){
        Executors.newSingleThreadExecutor().submit( () -> {
            try{ BufferedReader br = new BufferedReader(new FileReader(CSVVue.getLink(1)));String ligne ;
                while ((ligne = br.readLine()) != null) livreController.insert(ligne.split(","));
            }catch (IOException ex) { vue.printe("Erreur de fichier"); } catch (Exception e) { vue.printe("Erreur de connection."); }
        });
    }
    private static void saveEtudiant() {
        Executors.newSingleThreadExecutor().submit( () -> {
            try { PrintWriter out = new PrintWriter(new File(CSVVue.getLink(2)));
                DB.getDSL().selectFrom(Etudiant.ETUDIANT).stream().forEach(e -> { out.println(e.getCin() + "," + e.getNom() + "," + e.getPrenom() + "," + e.getFiliere()); });
                out.close();
            }catch (SQLException | ClassNotFoundException e) { vue.printe("Erreur de connection."); } catch (FileNotFoundException e) { vue.printe("Erreur de fichier."); }
        });
    }
    private static void saveLivre() {
        Executors.newSingleThreadExecutor().submit( () -> {
            try{ PrintWriter out = new PrintWriter( new File(CSVVue.getLink(2)) );
                DB.getDSL().selectFrom(Livre.LIVRE).stream().forEach(l -> { out.println( l.getTitre() + "," + l.getNumedition().toString() + "," + l.getDateapparition() + "," + l.getStock().toString()); });
                out.close();
            }catch (SQLException | ClassNotFoundException e) { vue.printe("Erreur de connection."); }catch (FileNotFoundException e) { vue.printe("Erreur de fichier."); }
        });
    }
}
