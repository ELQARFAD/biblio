package Controllers;
import Models.DB;
import Models.generated.tables.Emprunte;
import Models.generated.tables.Livre;
import Vues.empruntVue;
import Vues.livreVue;
import Vues.vue;
import java.util.List;

public class empruntController {
    public static void emprunter(){
        try {
            String [] tab = empruntVue.emprunt();
            int nb = DB.getDSL().selectFrom(Emprunte.EMPRUNTE).where(Emprunte.EMPRUNTE.CIN_ETUDIANT.eq(tab[1])).fetchCount();
            if(nb < 3){
                DB.getDSL().insertInto(Emprunte.EMPRUNTE,Emprunte.EMPRUNTE.CIN_ETUDIANT,Emprunte.EMPRUNTE.ID_LIVRE).values(tab[1],Integer.parseInt(tab[0])).execute();
                int[] tab1 = { Integer.parseInt(tab[0]) , -1 };
                livreController.updateStock(tab1);
                vue.print(vue.success());
            }
            else{ vue.print("Vous avez déppasez le nombre des empruntes."); }
        }catch (Exception e) { vue.printe("Erreur de connection."); }
    }
    public static void remettre(){
        try {
            String cin = empruntVue.remettre();
            List<Integer> res = DB.getDSL().selectFrom(Emprunte.EMPRUNTE).where(Emprunte.EMPRUNTE.CIN_ETUDIANT.eq(cin)).fetch().getValues(Emprunte.EMPRUNTE.ID_LIVRE);
            DB.getDSL().selectFrom(Livre.LIVRE).where(Livre.LIVRE.ID.in(res)).fetch().forEach(l -> vue.print(livreVue.toString(l)));
            int id = empruntVue.remettre1();
            DB.getDSL().delete(Emprunte.EMPRUNTE).where(Emprunte.EMPRUNTE.ID_LIVRE.eq(id),Emprunte.EMPRUNTE.CIN_ETUDIANT.eq(cin)).execute();
            int[] tab = { id , 1 };
            livreController.updateStock(tab);
            vue.print(vue.success());
        }catch (Exception e) { vue.printe("Erreur de connection."); }
    }
}
