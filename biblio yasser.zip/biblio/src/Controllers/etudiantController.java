package Controllers;
import Models.DB;
import Models.generated.tables.Etudiant;
import Vues.etudiantVue;
import Vues.vue;
import java.sql.SQLException;

public class etudiantController {
    public static void menuetudiant(){
        int choix = etudiantVue.menuetudiant();
        try{
            switch (choix){
                case 1: getAll(); break;
                case 2: insert(etudiantVue.insert()); vue.print(vue.success()); break;
                case 3: update(etudiantVue.update()); vue.print(vue.success()); break;
                case 4: delete(etudiantVue.delete()); vue.print(vue.success()); break;
                default:vue.NV(); }
        }catch (Exception e){ vue.printe("Erreur de connection."); }
        vue.res(); menuetudiant();
    }
    public static void getAll()  { try{ DB.getDSL().selectFrom(Etudiant.ETUDIANT).stream().forEach(e -> vue.print(etudiantVue.toString(e))); } catch(Exception e){ vue.printe("Erreur de connection."); } }
    static void insert(String[] tab) throws SQLException, ClassNotFoundException { DB.getDSL().insertInto(Etudiant.ETUDIANT,Etudiant.ETUDIANT.CIN,Etudiant.ETUDIANT.NOM,Etudiant.ETUDIANT.PRENOM,Etudiant.ETUDIANT.FILIERE).values(tab[0],tab[1],tab[2],tab[3]).execute(); }
    private static void delete(String cin) throws SQLException, ClassNotFoundException { DB.getDSL().delete(Etudiant.ETUDIANT).where(Etudiant.ETUDIANT.CIN.eq(cin)).execute(); }
    private static void update(String[] tab) throws SQLException, ClassNotFoundException {
        if( !tab[1].isEmpty() ) DB.getDSL().update(Etudiant.ETUDIANT).set(Etudiant.ETUDIANT.NOM , tab[1]).where(Etudiant.ETUDIANT.CIN.eq(tab[0])).execute();
        if( !tab[2].isEmpty() ) DB.getDSL().update(Etudiant.ETUDIANT).set(Etudiant.ETUDIANT.PRENOM , tab[2]).where(Etudiant.ETUDIANT.CIN.eq(tab[0])).execute();
        if( !tab[3].isEmpty() ) DB.getDSL().update(Etudiant.ETUDIANT).set(Etudiant.ETUDIANT.FILIERE , tab[3]).where(Etudiant.ETUDIANT.CIN.eq(tab[0])).execute();
    }
}
