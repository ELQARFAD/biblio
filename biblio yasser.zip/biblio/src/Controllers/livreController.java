package Controllers;
import Models.DB;
import Models.generated.tables.Livre;
import Vues.livreVue;
import Vues.vue;
import java.sql.SQLException;

public class livreController {
    public static void menulivre(){
        try{
            int choix = livreVue.menulivre();
            switch (choix){
                case 1: getAll(); break;
                case 2: updateStock(livreVue.updateStock());vue.print(vue.success()); break;
                case 3: insert(livreVue.insert()); vue.print(vue.success()); break;
                case 4: update(livreVue.update()); vue.print(vue.success()); break;
                case 5: delete(livreVue.delete()); vue.print(vue.success()); break;
                default:vue.NV(); menulivre(); }
        }catch (Exception e){ vue.printe("Erreur de connection.\n"); } vue.res(); menulivre();
    }
    public static void getAll() { try { DB.getDSL().selectFrom(Livre.LIVRE).stream().forEach(e -> vue.print(livreVue.toString(e))); }catch (Exception e) { vue.printe("Erreur de connection."); } }
    static void updateStock(int[] tab) throws  ClassNotFoundException {
        try {
            int nov = tab[1] + DB.getDSL().selectFrom(Livre.LIVRE).where(Livre.LIVRE.ID.eq(tab[0])).fetchSingle().get(Livre.LIVRE.STOCK);
            DB.getDSL().update(Livre.LIVRE).set(Livre.LIVRE.STOCK,nov).where(Livre.LIVRE.ID.eq(tab[0])).execute();
        }catch (SQLException e) { vue.printe("Erreur de données.\n"); }
    }
    static void insert(String[] tab) throws  ClassNotFoundException {
        try { DB.getDSL().insertInto(Livre.LIVRE,Livre.LIVRE.TITRE,Livre.LIVRE.NUMEDITION,Livre.LIVRE.DATEAPPARITION,Livre.LIVRE.STOCK).values(tab[0],Integer.parseInt(tab[1]),tab[2],Integer.parseInt(tab[3])).execute();
        }catch (SQLException e) { vue.printe("Erreur de données.\n"); }
    }
    private static void update(String[] tab) throws SQLException, ClassNotFoundException {
        if( !tab[1].isEmpty() ) DB.getDSL().update(Livre.LIVRE).set(Livre.LIVRE.TITRE,tab[1]).where(Livre.LIVRE.ID.eq(Integer.parseInt(tab[0]))).execute();
        if( !tab[2].isEmpty() ) DB.getDSL().update(Livre.LIVRE).set(Livre.LIVRE.NUMEDITION,Integer.parseInt(tab[2])).where(Livre.LIVRE.ID.eq(Integer.parseInt(tab[0]))).execute();
        if( !tab[3].isEmpty() ) DB.getDSL().update(Livre.LIVRE).set(Livre.LIVRE.DATEAPPARITION,tab[3]).where(Livre.LIVRE.ID.eq(Integer.parseInt(tab[0]))).execute();
        if( !tab[4].isEmpty() ) DB.getDSL().update(Livre.LIVRE).set(Livre.LIVRE.STOCK,Integer.parseInt(tab[4])).where(Livre.LIVRE.ID.eq(Integer.parseInt(tab[0]))).execute();
    }
    private static void delete(int id) throws SQLException, ClassNotFoundException { DB.getDSL().delete(Livre.LIVRE).where(Livre.LIVRE.ID.eq(id)).execute(); }
}
