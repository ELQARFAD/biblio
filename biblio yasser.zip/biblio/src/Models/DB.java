package Models;
import org.jooq.DSLContext;
import org.jooq.SQLDialect;
import org.jooq.impl.DSL;
import java.sql.*;

public class DB {
    private static Connection con;
    private DB() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost/biblio", "root", "");
    }
    public static DSLContext getDSL() throws SQLException, ClassNotFoundException { return DSL.using(DB.getConnection(), SQLDialect.MYSQL); }
    private static Connection getConnection() throws SQLException, ClassNotFoundException { new DB(); return con; }
}

