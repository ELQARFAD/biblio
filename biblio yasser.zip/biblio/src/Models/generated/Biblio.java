package Models.generated;

import Models.generated.tables.Emprunte;
import Models.generated.tables.Etudiant;
import Models.generated.tables.Livre;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.jooq.Catalog;
import org.jooq.Table;
import org.jooq.impl.SchemaImpl;

@SuppressWarnings({ "all", "unchecked", "rawtypes" })
public class Biblio extends SchemaImpl {
    private static final long serialVersionUID = -934430095;
    /**
     * The reference instance of <code>biblio</code>
     */
    public static final Biblio BIBLIO = new Biblio();
    /**
     * The table <code>biblio.emprunte</code>.
     */
    public final Emprunte EMPRUNTE = Models.generated.tables.Emprunte.EMPRUNTE;
    /**
     * The table <code>biblio.etudiant</code>.
     */
    public final Etudiant ETUDIANT = Models.generated.tables.Etudiant.ETUDIANT;
    /**
     * The table <code>biblio.livre</code>.
     */
    public final Livre LIVRE = Models.generated.tables.Livre.LIVRE;
    /**
     * No further instances allowed
     */
    private Biblio() {
        super("biblio", null);
    }
    @Override public Catalog getCatalog() {
        return DefaultCatalog.DEFAULT_CATALOG;
    }
    @Override public final List<Table<?>> getTables() {
        List result = new ArrayList();
        result.addAll(getTables0());
        return result;
    }
    private final List<Table<?>> getTables0() {
        return Arrays.<Table<?>>asList(
            Emprunte.EMPRUNTE,
            Etudiant.ETUDIANT,
            Livre.LIVRE);
    }
}
