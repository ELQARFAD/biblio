package Models.generated;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.jooq.Schema;
import org.jooq.impl.CatalogImpl;

@SuppressWarnings({ "all", "unchecked", "rawtypes" })
public class DefaultCatalog extends CatalogImpl {
    private static final long serialVersionUID = 2066929172;
    /**
     * The reference instance of <code></code>
     */
    public static final DefaultCatalog DEFAULT_CATALOG = new DefaultCatalog();
    /**
     * The schema <code>biblio</code>.
     */
    public final Biblio BIBLIO = Models.generated.Biblio.BIBLIO;
    /**
     * No further instances allowed
     */
    private DefaultCatalog() {
        super("");
    }
    @Override public final List<Schema> getSchemas() {
        List result = new ArrayList();
        result.addAll(getSchemas0());
        return result;
    }
    private final List<Schema> getSchemas0() {
        return Arrays.<Schema>asList(
            Biblio.BIBLIO);
    }
}
