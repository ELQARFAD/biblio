package Models.generated;

import Models.generated.tables.Emprunte;
import Models.generated.tables.Etudiant;
import Models.generated.tables.Livre;
import org.jooq.Index;
import org.jooq.OrderField;
import org.jooq.impl.Internal;

@SuppressWarnings({ "all", "unchecked", "rawtypes" })
public class Indexes {

    // -------------------------------------------------------------------------
    // INDEX definitions
    // -------------------------------------------------------------------------

    public static final Index EMPRUNTE_CIN_ETUDIANT = Indexes0.EMPRUNTE_CIN_ETUDIANT;
    public static final Index EMPRUNTE_ID_LIVRE = Indexes0.EMPRUNTE_ID_LIVRE;
    public static final Index EMPRUNTE_PRIMARY = Indexes0.EMPRUNTE_PRIMARY;
    public static final Index ETUDIANT_PRIMARY = Indexes0.ETUDIANT_PRIMARY;
    public static final Index LIVRE_PRIMARY = Indexes0.LIVRE_PRIMARY;

    // -------------------------------------------------------------------------
    // [#1459] distribute members to avoid static initialisers > 64kb
    // -------------------------------------------------------------------------

    private static class Indexes0 {
        public static Index EMPRUNTE_CIN_ETUDIANT = Internal.createIndex("cin_etudiant", Emprunte.EMPRUNTE, new OrderField[] { Emprunte.EMPRUNTE.CIN_ETUDIANT }, false);
        public static Index EMPRUNTE_ID_LIVRE = Internal.createIndex("id_livre", Emprunte.EMPRUNTE, new OrderField[] { Emprunte.EMPRUNTE.ID_LIVRE }, false);
        public static Index EMPRUNTE_PRIMARY = Internal.createIndex("PRIMARY", Emprunte.EMPRUNTE, new OrderField[] { Emprunte.EMPRUNTE.ID }, true);
        public static Index ETUDIANT_PRIMARY = Internal.createIndex("PRIMARY", Etudiant.ETUDIANT, new OrderField[] { Etudiant.ETUDIANT.CIN }, true);
        public static Index LIVRE_PRIMARY = Internal.createIndex("PRIMARY", Livre.LIVRE, new OrderField[] { Livre.LIVRE.ID }, true);
    }
}
