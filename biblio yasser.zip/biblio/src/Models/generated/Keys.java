package Models.generated;

import Models.generated.tables.Emprunte;
import Models.generated.tables.Etudiant;
import Models.generated.tables.Livre;
import Models.generated.tables.records.EmprunteRecord;
import Models.generated.tables.records.EtudiantRecord;
import Models.generated.tables.records.LivreRecord;
import org.jooq.ForeignKey;
import org.jooq.Identity;
import org.jooq.UniqueKey;
import org.jooq.impl.Internal;

@SuppressWarnings({ "all", "unchecked", "rawtypes" })
public class Keys {

    // -------------------------------------------------------------------------
    // IDENTITY definitions
    // -------------------------------------------------------------------------

    public static final Identity<EmprunteRecord, Integer> IDENTITY_EMPRUNTE = Identities0.IDENTITY_EMPRUNTE;
    public static final Identity<LivreRecord, Integer> IDENTITY_LIVRE = Identities0.IDENTITY_LIVRE;

    // -------------------------------------------------------------------------
    // UNIQUE and PRIMARY KEY definitions
    // -------------------------------------------------------------------------

    public static final UniqueKey<EmprunteRecord> KEY_EMPRUNTE_PRIMARY = UniqueKeys0.KEY_EMPRUNTE_PRIMARY;
    public static final UniqueKey<EtudiantRecord> KEY_ETUDIANT_PRIMARY = UniqueKeys0.KEY_ETUDIANT_PRIMARY;
    public static final UniqueKey<LivreRecord> KEY_LIVRE_PRIMARY = UniqueKeys0.KEY_LIVRE_PRIMARY;

    // -------------------------------------------------------------------------
    // FOREIGN KEY definitions
    // -------------------------------------------------------------------------

    public static final ForeignKey<EmprunteRecord, EtudiantRecord> EMPRUNTE_IBFK_1 = ForeignKeys0.EMPRUNTE_IBFK_1;
    public static final ForeignKey<EmprunteRecord, LivreRecord> EMPRUNTE_IBFK_2 = ForeignKeys0.EMPRUNTE_IBFK_2;

    // -------------------------------------------------------------------------
    // [#1459] distribute members to avoid static initialisers > 64kb
    // -------------------------------------------------------------------------

    private static class Identities0 {
        public static Identity<EmprunteRecord, Integer> IDENTITY_EMPRUNTE = Internal.createIdentity(Emprunte.EMPRUNTE, Emprunte.EMPRUNTE.ID);
        public static Identity<LivreRecord, Integer> IDENTITY_LIVRE = Internal.createIdentity(Livre.LIVRE, Livre.LIVRE.ID);
    }

    private static class UniqueKeys0 {
        public static final UniqueKey<EmprunteRecord> KEY_EMPRUNTE_PRIMARY = Internal.createUniqueKey(Emprunte.EMPRUNTE, "KEY_emprunte_PRIMARY", Emprunte.EMPRUNTE.ID);
        public static final UniqueKey<EtudiantRecord> KEY_ETUDIANT_PRIMARY = Internal.createUniqueKey(Etudiant.ETUDIANT, "KEY_etudiant_PRIMARY", Etudiant.ETUDIANT.CIN);
        public static final UniqueKey<LivreRecord> KEY_LIVRE_PRIMARY = Internal.createUniqueKey(Livre.LIVRE, "KEY_livre_PRIMARY", Livre.LIVRE.ID);
    }

    private static class ForeignKeys0 {
        public static final ForeignKey<EmprunteRecord, EtudiantRecord> EMPRUNTE_IBFK_1 = Internal.createForeignKey(Models.generated.Keys.KEY_ETUDIANT_PRIMARY, Emprunte.EMPRUNTE, "emprunte_ibfk_1", Emprunte.EMPRUNTE.CIN_ETUDIANT);
        public static final ForeignKey<EmprunteRecord, LivreRecord> EMPRUNTE_IBFK_2 = Internal.createForeignKey(Models.generated.Keys.KEY_LIVRE_PRIMARY, Emprunte.EMPRUNTE, "emprunte_ibfk_2", Emprunte.EMPRUNTE.ID_LIVRE);
    }
}
