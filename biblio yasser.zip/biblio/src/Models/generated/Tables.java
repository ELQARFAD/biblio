package Models.generated;

import Models.generated.tables.Emprunte;
import Models.generated.tables.Etudiant;
import Models.generated.tables.Livre;

@SuppressWarnings({ "all", "unchecked", "rawtypes" })
public class Tables {
    /**
     * The table <code>biblio.emprunte</code>.
     */
    public static final Emprunte EMPRUNTE = Emprunte.EMPRUNTE;
    /**
     * The table <code>biblio.etudiant</code>.
     */
    public static final Etudiant ETUDIANT = Etudiant.ETUDIANT;
    /**
     * The table <code>biblio.livre</code>.
     */
    public static final Livre LIVRE = Livre.LIVRE;
}
