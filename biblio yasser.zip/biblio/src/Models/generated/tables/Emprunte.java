package Models.generated.tables;

import Models.generated.Biblio;
import Models.generated.Indexes;
import Models.generated.Keys;
import Models.generated.tables.records.EmprunteRecord;
import java.util.Arrays;
import java.util.List;
import org.jooq.Field;
import org.jooq.ForeignKey;
import org.jooq.Identity;
import org.jooq.Index;
import org.jooq.Name;
import org.jooq.Record;
import org.jooq.Row3;
import org.jooq.Schema;
import org.jooq.Table;
import org.jooq.TableField;
import org.jooq.UniqueKey;
import org.jooq.impl.DSL;
import org.jooq.impl.TableImpl;

@SuppressWarnings({ "all", "unchecked", "rawtypes" })
public class Emprunte extends TableImpl<EmprunteRecord> {
    private static final long serialVersionUID = -11262029;
    /**
     * The reference instance of <code>biblio.emprunte</code>
     */
    public static final Emprunte EMPRUNTE = new Emprunte();
    /**
     * The class holding records for this type
     */
    @Override public Class<EmprunteRecord> getRecordType() {
        return EmprunteRecord.class;
    }
    /**
     * The column <code>biblio.emprunte.id</code>.
     */
    public final TableField<EmprunteRecord, Integer> ID = createField(DSL.name("id"), org.jooq.impl.SQLDataType.INTEGER.nullable(false).identity(true), this, "");
    /**
     * The column <code>biblio.emprunte.cin_etudiant</code>.
     */
    public final TableField<EmprunteRecord, String> CIN_ETUDIANT = createField(DSL.name("cin_etudiant"), org.jooq.impl.SQLDataType.VARCHAR(10).defaultValue(org.jooq.impl.DSL.inline("NULL", org.jooq.impl.SQLDataType.VARCHAR)), this, "");
    /**
     * The column <code>biblio.emprunte.id_livre</code>.
     */
    public final TableField<EmprunteRecord, Integer> ID_LIVRE = createField(DSL.name("id_livre"), org.jooq.impl.SQLDataType.INTEGER.defaultValue(org.jooq.impl.DSL.inline("NULL", org.jooq.impl.SQLDataType.INTEGER)), this, "");
    /**
     * Create a <code>biblio.emprunte</code> table reference
     */
    public Emprunte() {
        this(DSL.name("emprunte"), null);
    }
    /**
     * Create an aliased <code>biblio.emprunte</code> table reference
     */
    public Emprunte(String alias) {
        this(DSL.name(alias), EMPRUNTE);
    }
    /**
     * Create an aliased <code>biblio.emprunte</code> table reference
     */
    public Emprunte(Name alias) {
        this(alias, EMPRUNTE);
    }
    private Emprunte(Name alias, Table<EmprunteRecord> aliased) {
        this(alias, aliased, null);
    }
    private Emprunte(Name alias, Table<EmprunteRecord> aliased, Field<?>[] parameters) { super(alias, null, aliased, parameters, DSL.comment("")); }
    public <O extends Record> Emprunte(Table<O> child, ForeignKey<O, EmprunteRecord> key) { super(child, key, EMPRUNTE); }
    @Override public Schema getSchema() {
        return Biblio.BIBLIO;
    }
    @Override public List<Index> getIndexes() { return Arrays.<Index>asList(Indexes.EMPRUNTE_CIN_ETUDIANT, Indexes.EMPRUNTE_ID_LIVRE, Indexes.EMPRUNTE_PRIMARY); }
    @Override public Identity<EmprunteRecord, Integer> getIdentity() {
        return Keys.IDENTITY_EMPRUNTE;
    }
    @Override public UniqueKey<EmprunteRecord> getPrimaryKey() {
        return Keys.KEY_EMPRUNTE_PRIMARY;
    }
    @Override public List<UniqueKey<EmprunteRecord>> getKeys() { return Arrays.<UniqueKey<EmprunteRecord>>asList(Keys.KEY_EMPRUNTE_PRIMARY); }
    @Override public List<ForeignKey<EmprunteRecord, ?>> getReferences() { return Arrays.<ForeignKey<EmprunteRecord, ?>>asList(Keys.EMPRUNTE_IBFK_1, Keys.EMPRUNTE_IBFK_2); }
    public Etudiant etudiant() {
        return new Etudiant(this, Keys.EMPRUNTE_IBFK_1);
    }
    public Livre livre() {
        return new Livre(this, Keys.EMPRUNTE_IBFK_2);
    }
    @Override public Emprunte as(String alias) {
        return new Emprunte(DSL.name(alias), this);
    }
    @Override public Emprunte as(Name alias) {
        return new Emprunte(alias, this);
    }
    /**
     * Rename this table
     */
    @Override public Emprunte rename(String name) {
        return new Emprunte(DSL.name(name), null);
    }
    /**
     * Rename this table
     */
    @Override public Emprunte rename(Name name) {
        return new Emprunte(name, null);
    }
    // Row3 type methods
    @Override public Row3<Integer, String, Integer> fieldsRow() {
        return (Row3) super.fieldsRow();
    }

}
