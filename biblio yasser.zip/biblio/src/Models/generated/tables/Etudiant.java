package Models.generated.tables;

import Models.generated.Biblio;
import Models.generated.Indexes;
import Models.generated.Keys;
import Models.generated.tables.records.EtudiantRecord;
import java.util.Arrays;
import java.util.List;
import org.jooq.Field;
import org.jooq.ForeignKey;
import org.jooq.Index;
import org.jooq.Name;
import org.jooq.Record;
import org.jooq.Row4;
import org.jooq.Schema;
import org.jooq.Table;
import org.jooq.TableField;
import org.jooq.UniqueKey;
import org.jooq.impl.DSL;
import org.jooq.impl.TableImpl;

@SuppressWarnings({ "all", "unchecked", "rawtypes" })
public class Etudiant extends TableImpl<EtudiantRecord> {
    private static final long serialVersionUID = -246746393;
    /**
     * The reference instance of <code>biblio.etudiant</code>
     */
    public static final Etudiant ETUDIANT = new Etudiant();
    /**
     * The class holding records for this type
     */
    @Override public Class<EtudiantRecord> getRecordType() {
        return EtudiantRecord.class;
    }
    /**
     * The column <code>biblio.etudiant.cin</code>.
     */
    public final TableField<EtudiantRecord, String> CIN = createField(DSL.name("cin"), org.jooq.impl.SQLDataType.VARCHAR(10).nullable(false), this, "");
    /**
     * The column <code>biblio.etudiant.nom</code>.
     */
    public final TableField<EtudiantRecord, String> NOM = createField(DSL.name("nom"), org.jooq.impl.SQLDataType.VARCHAR(30).nullable(false), this, "");
    /**
     * The column <code>biblio.etudiant.prenom</code>.
     */
    public final TableField<EtudiantRecord, String> PRENOM = createField(DSL.name("prenom"), org.jooq.impl.SQLDataType.VARCHAR(30).nullable(false), this, "");
    /**
     * The column <code>biblio.etudiant.filiere</code>.
     */
    public final TableField<EtudiantRecord, String> FILIERE = createField(DSL.name("filiere"), org.jooq.impl.SQLDataType.VARCHAR(50).nullable(false), this, "");
    /**
     * Create a <code>biblio.etudiant</code> table reference
     */
    public Etudiant() {
        this(DSL.name("etudiant"), null);
    }
    /**
     * Create an aliased <code>biblio.etudiant</code> table reference
     */
    public Etudiant(String alias) {
        this(DSL.name(alias), ETUDIANT);
    }
    /**
     * Create an aliased <code>biblio.etudiant</code> table reference
     */
    public Etudiant(Name alias) {
        this(alias, ETUDIANT);
    }
    private Etudiant(Name alias, Table<EtudiantRecord> aliased) {
        this(alias, aliased, null);
    }
    private Etudiant(Name alias, Table<EtudiantRecord> aliased, Field<?>[] parameters) { super(alias, null, aliased, parameters, DSL.comment("")); }
    public <O extends Record> Etudiant(Table<O> child, ForeignKey<O, EtudiantRecord> key) { super(child, key, ETUDIANT); }
    @Override public Schema getSchema() {
        return Biblio.BIBLIO;
    }
    @Override public List<Index> getIndexes() {
        return Arrays.<Index>asList(Indexes.ETUDIANT_PRIMARY);
    }
    @Override public UniqueKey<EtudiantRecord> getPrimaryKey() {
        return Keys.KEY_ETUDIANT_PRIMARY;
    }
    @Override public List<UniqueKey<EtudiantRecord>> getKeys() { return Arrays.<UniqueKey<EtudiantRecord>>asList(Keys.KEY_ETUDIANT_PRIMARY); }
    @Override public Etudiant as(String alias) {
        return new Etudiant(DSL.name(alias), this);
    }
    @Override public Etudiant as(Name alias) {
        return new Etudiant(alias, this);
    }
    /**
     * Rename this table
     */
    @Override public Etudiant rename(String name) {
        return new Etudiant(DSL.name(name), null);
    }
    /**
     * Rename this table
     */
    @Override public Etudiant rename(Name name) {
        return new Etudiant(name, null);
    }
    // Row4 type methods
    @Override public Row4<String, String, String, String> fieldsRow() {
        return (Row4) super.fieldsRow();
    }

}
