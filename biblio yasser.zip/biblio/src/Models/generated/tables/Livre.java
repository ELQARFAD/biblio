package Models.generated.tables;

import Models.generated.Biblio;
import Models.generated.Indexes;
import Models.generated.Keys;
import Models.generated.tables.records.LivreRecord;
import java.util.Arrays;
import java.util.List;
import org.jooq.Field;
import org.jooq.ForeignKey;
import org.jooq.Identity;
import org.jooq.Index;
import org.jooq.Name;
import org.jooq.Record;
import org.jooq.Row5;
import org.jooq.Schema;
import org.jooq.Table;
import org.jooq.TableField;
import org.jooq.UniqueKey;
import org.jooq.impl.DSL;
import org.jooq.impl.TableImpl;

@SuppressWarnings({ "all", "unchecked", "rawtypes" })
public class Livre extends TableImpl<LivreRecord> {
    private static final long serialVersionUID = 1011674791;
    /**
     * The reference instance of <code>biblio.livre</code>
     */
    public static final Livre LIVRE = new Livre();
    /**
     * The class holding records for this type
     */
    @Override public Class<LivreRecord> getRecordType() {
        return LivreRecord.class;
    }
    /**
     * The column <code>biblio.livre.id</code>.
     */
    public final TableField<LivreRecord, Integer> ID = createField(DSL.name("id"), org.jooq.impl.SQLDataType.INTEGER.nullable(false).identity(true), this, "");
    /**
     * The column <code>biblio.livre.titre</code>.
     */
    public final TableField<LivreRecord, String> TITRE = createField(DSL.name("titre"), org.jooq.impl.SQLDataType.VARCHAR(50).nullable(false), this, "");
    /**
     * The column <code>biblio.livre.numEdition</code>.
     */
    public final TableField<LivreRecord, Integer> NUMEDITION = createField(DSL.name("numEdition"), org.jooq.impl.SQLDataType.INTEGER.nullable(false), this, "");
    /**
     * The column <code>biblio.livre.dateApparition</code>.
     */
    public final TableField<LivreRecord, String> DATEAPPARITION = createField(DSL.name("dateApparition"), org.jooq.impl.SQLDataType.VARCHAR(10).nullable(false), this, "");
    /**
     * The column <code>biblio.livre.stock</code>.
     */
    public final TableField<LivreRecord, Integer> STOCK = createField(DSL.name("stock"), org.jooq.impl.SQLDataType.INTEGER.defaultValue(org.jooq.impl.DSL.inline("0", org.jooq.impl.SQLDataType.INTEGER)), this, "");
    /**
     * Create a <code>biblio.livre</code> table reference
     */
    public Livre() {
        this(DSL.name("livre"), null);
    }
    /**
     * Create an aliased <code>biblio.livre</code> table reference
     */
    public Livre(String alias) {
        this(DSL.name(alias), LIVRE);
    }
    /**
     * Create an aliased <code>biblio.livre</code> table reference
     */
    public Livre(Name alias) {
        this(alias, LIVRE);
    }
    private Livre(Name alias, Table<LivreRecord> aliased) {
        this(alias, aliased, null);
    }
    private Livre(Name alias, Table<LivreRecord> aliased, Field<?>[] parameters) { super(alias, null, aliased, parameters, DSL.comment("")); }
    public <O extends Record> Livre(Table<O> child, ForeignKey<O, LivreRecord> key) {
        super(child, key, LIVRE);
    }
    @Override public Schema getSchema() {
        return Biblio.BIBLIO;
    }
    @Override public List<Index> getIndexes() {
        return Arrays.<Index>asList(Indexes.LIVRE_PRIMARY);
    }
    @Override public Identity<LivreRecord, Integer> getIdentity() {
        return Keys.IDENTITY_LIVRE;
    }
    @Override public UniqueKey<LivreRecord> getPrimaryKey() {
        return Keys.KEY_LIVRE_PRIMARY;
    }
    @Override public List<UniqueKey<LivreRecord>> getKeys() { return Arrays.<UniqueKey<LivreRecord>>asList(Keys.KEY_LIVRE_PRIMARY); }
    @Override public Livre as(String alias) {
        return new Livre(DSL.name(alias), this);
    }
    @Override public Livre as(Name alias) {
        return new Livre(alias, this);
    }
    /**
     * Rename this table
     */
    @Override public Livre rename(String name) {
        return new Livre(DSL.name(name), null);
    }
    /**
     * Rename this table
     */
    @Override public Livre rename(Name name) {
        return new Livre(name, null);
    }
    // Row5 type methods
    @Override public Row5<Integer, String, Integer, String, Integer> fieldsRow() {
        return (Row5) super.fieldsRow();
    }
}
