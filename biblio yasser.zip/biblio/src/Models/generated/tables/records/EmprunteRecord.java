package Models.generated.tables.records;

import Models.generated.tables.Emprunte;
import org.jooq.Field;
import org.jooq.Record1;
import org.jooq.Record3;
import org.jooq.Row3;
import org.jooq.impl.UpdatableRecordImpl;

@SuppressWarnings({ "all", "unchecked", "rawtypes" })
public class EmprunteRecord extends UpdatableRecordImpl<EmprunteRecord> implements Record3<Integer, String, Integer> {

    private static final long serialVersionUID = 1291076685;

    /**
     * Setter for <code>biblio.emprunte.id</code>.
     */
    public void setId(Integer value) {
        set(0, value);
    }

    /**
     * Getter for <code>biblio.emprunte.id</code>.
     */
    public Integer getId() {
        return (Integer) get(0);
    }

    /**
     * Setter for <code>biblio.emprunte.cin_etudiant</code>.
     */
    public void setCinEtudiant(String value) {
        set(1, value);
    }

    /**
     * Getter for <code>biblio.emprunte.cin_etudiant</code>.
     */
    public String getCinEtudiant() {
        return (String) get(1);
    }

    /**
     * Setter for <code>biblio.emprunte.id_livre</code>.
     */
    public void setIdLivre(Integer value) {
        set(2, value);
    }

    /**
     * Getter for <code>biblio.emprunte.id_livre</code>.
     */
    public Integer getIdLivre() {
        return (Integer) get(2);
    }

    // -------------------------------------------------------------------------
    // Primary key information
    // -------------------------------------------------------------------------

    @Override
    public Record1<Integer> key() {
        return (Record1) super.key();
    }

    // -------------------------------------------------------------------------
    // Record3 type implementation
    // -------------------------------------------------------------------------

    @Override
    public Row3<Integer, String, Integer> fieldsRow() {
        return (Row3) super.fieldsRow();
    }

    @Override
    public Row3<Integer, String, Integer> valuesRow() {
        return (Row3) super.valuesRow();
    }

    @Override
    public Field<Integer> field1() {
        return Emprunte.EMPRUNTE.ID;
    }

    @Override
    public Field<String> field2() {
        return Emprunte.EMPRUNTE.CIN_ETUDIANT;
    }

    @Override
    public Field<Integer> field3() {
        return Emprunte.EMPRUNTE.ID_LIVRE;
    }

    @Override
    public Integer component1() {
        return getId();
    }

    @Override
    public String component2() {
        return getCinEtudiant();
    }

    @Override
    public Integer component3() {
        return getIdLivre();
    }

    @Override
    public Integer value1() {
        return getId();
    }

    @Override
    public String value2() {
        return getCinEtudiant();
    }

    @Override
    public Integer value3() {
        return getIdLivre();
    }

    @Override
    public EmprunteRecord value1(Integer value) {
        setId(value);
        return this;
    }

    @Override
    public EmprunteRecord value2(String value) {
        setCinEtudiant(value);
        return this;
    }

    @Override
    public EmprunteRecord value3(Integer value) {
        setIdLivre(value);
        return this;
    }

    @Override
    public EmprunteRecord values(Integer value1, String value2, Integer value3) {
        value1(value1);
        value2(value2);
        value3(value3);
        return this;
    }

    // -------------------------------------------------------------------------
    // Constructors
    // -------------------------------------------------------------------------

    /**
     * Create a detached EmprunteRecord
     */
    public EmprunteRecord() {
        super(Emprunte.EMPRUNTE);
    }

    /**
     * Create a detached, initialised EmprunteRecord
     */
    public EmprunteRecord(Integer id, String cinEtudiant, Integer idLivre) {
        super(Emprunte.EMPRUNTE);

        set(0, id);
        set(1, cinEtudiant);
        set(2, idLivre);
    }
}
