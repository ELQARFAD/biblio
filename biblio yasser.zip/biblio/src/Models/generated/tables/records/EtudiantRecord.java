package Models.generated.tables.records;

import Models.generated.tables.Etudiant;
import org.jooq.Field;
import org.jooq.Record1;
import org.jooq.Record4;
import org.jooq.Row4;
import org.jooq.impl.UpdatableRecordImpl;

@SuppressWarnings({ "all", "unchecked", "rawtypes" })
public class EtudiantRecord extends UpdatableRecordImpl<EtudiantRecord> implements Record4<String, String, String, String> {
    private static final long serialVersionUID = 1345967517;

    /**
     * Setter for <code>biblio.etudiant.cin</code>.
     */
    public void setCin(String value) {
        set(0, value);
    }

    /**
     * Getter for <code>biblio.etudiant.cin</code>.
     */
    public String getCin() {
        return (String) get(0);
    }

    /**
     * Setter for <code>biblio.etudiant.nom</code>.
     */
    public void setNom(String value) {
        set(1, value);
    }

    /**
     * Getter for <code>biblio.etudiant.nom</code>.
     */
    public String getNom() {
        return (String) get(1);
    }

    /**
     * Setter for <code>biblio.etudiant.prenom</code>.
     */
    public void setPrenom(String value) {
        set(2, value);
    }

    /**
     * Getter for <code>biblio.etudiant.prenom</code>.
     */
    public String getPrenom() {
        return (String) get(2);
    }

    /**
     * Setter for <code>biblio.etudiant.filiere</code>.
     */
    public void setFiliere(String value) {
        set(3, value);
    }

    /**
     * Getter for <code>biblio.etudiant.filiere</code>.
     */
    public String getFiliere() {
        return (String) get(3);
    }

    // -------------------------------------------------------------------------
    // Primary key information
    // -------------------------------------------------------------------------

    @Override
    public Record1<String> key() {
        return (Record1) super.key();
    }

    // -------------------------------------------------------------------------
    // Record4 type implementation
    // -------------------------------------------------------------------------

    @Override
    public Row4<String, String, String, String> fieldsRow() {
        return (Row4) super.fieldsRow();
    }

    @Override
    public Row4<String, String, String, String> valuesRow() {
        return (Row4) super.valuesRow();
    }

    @Override
    public Field<String> field1() {
        return Etudiant.ETUDIANT.CIN;
    }

    @Override
    public Field<String> field2() {
        return Etudiant.ETUDIANT.NOM;
    }

    @Override
    public Field<String> field3() {
        return Etudiant.ETUDIANT.PRENOM;
    }

    @Override
    public Field<String> field4() {
        return Etudiant.ETUDIANT.FILIERE;
    }

    @Override
    public String component1() {
        return getCin();
    }

    @Override
    public String component2() {
        return getNom();
    }

    @Override
    public String component3() {
        return getPrenom();
    }

    @Override
    public String component4() {
        return getFiliere();
    }

    @Override
    public String value1() {
        return getCin();
    }

    @Override
    public String value2() {
        return getNom();
    }

    @Override
    public String value3() {
        return getPrenom();
    }

    @Override
    public String value4() {
        return getFiliere();
    }

    @Override
    public EtudiantRecord value1(String value) {
        setCin(value);
        return this;
    }

    @Override
    public EtudiantRecord value2(String value) {
        setNom(value);
        return this;
    }

    @Override
    public EtudiantRecord value3(String value) {
        setPrenom(value);
        return this;
    }

    @Override
    public EtudiantRecord value4(String value) {
        setFiliere(value);
        return this;
    }

    @Override
    public EtudiantRecord values(String value1, String value2, String value3, String value4) {
        value1(value1);
        value2(value2);
        value3(value3);
        value4(value4);
        return this;
    }

    // -------------------------------------------------------------------------
    // Constructors
    // -------------------------------------------------------------------------

    /**
     * Create a detached EtudiantRecord
     */
    public EtudiantRecord() {
        super(Etudiant.ETUDIANT);
    }

    /**
     * Create a detached, initialised EtudiantRecord
     */
    public EtudiantRecord(String cin, String nom, String prenom, String filiere) {
        super(Etudiant.ETUDIANT);

        set(0, cin);
        set(1, nom);
        set(2, prenom);
        set(3, filiere);
    }
}
