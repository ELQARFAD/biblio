package Models.generated.tables.records;

import Models.generated.tables.Livre;
import org.jooq.Field;
import org.jooq.Record1;
import org.jooq.Record5;
import org.jooq.Row5;
import org.jooq.impl.UpdatableRecordImpl;

@SuppressWarnings({ "all", "unchecked", "rawtypes" })
public class LivreRecord extends UpdatableRecordImpl<LivreRecord> implements Record5<Integer, String, Integer, String, Integer> {
    private static final long serialVersionUID = -843446507;

    /**
     * Setter for <code>biblio.livre.id</code>.
     */
    public void setId(Integer value) {
        set(0, value);
    }

    /**
     * Getter for <code>biblio.livre.id</code>.
     */
    public Integer getId() {
        return (Integer) get(0);
    }

    /**
     * Setter for <code>biblio.livre.titre</code>.
     */
    public void setTitre(String value) {
        set(1, value);
    }

    /**
     * Getter for <code>biblio.livre.titre</code>.
     */
    public String getTitre() {
        return (String) get(1);
    }

    /**
     * Setter for <code>biblio.livre.numEdition</code>.
     */
    public void setNumedition(Integer value) {
        set(2, value);
    }

    /**
     * Getter for <code>biblio.livre.numEdition</code>.
     */
    public Integer getNumedition() {
        return (Integer) get(2);
    }

    /**
     * Setter for <code>biblio.livre.dateApparition</code>.
     */
    public void setDateapparition(String value) {
        set(3, value);
    }

    /**
     * Getter for <code>biblio.livre.dateApparition</code>.
     */
    public String getDateapparition() {
        return (String) get(3);
    }

    /**
     * Setter for <code>biblio.livre.stock</code>.
     */
    public void setStock(Integer value) {
        set(4, value);
    }

    /**
     * Getter for <code>biblio.livre.stock</code>.
     */
    public Integer getStock() {
        return (Integer) get(4);
    }

    // -------------------------------------------------------------------------
    // Primary key information
    // -------------------------------------------------------------------------

    @Override
    public Record1<Integer> key() {
        return (Record1) super.key();
    }

    // -------------------------------------------------------------------------
    // Record5 type implementation
    // -------------------------------------------------------------------------

    @Override
    public Row5<Integer, String, Integer, String, Integer> fieldsRow() {
        return (Row5) super.fieldsRow();
    }

    @Override
    public Row5<Integer, String, Integer, String, Integer> valuesRow() {
        return (Row5) super.valuesRow();
    }

    @Override
    public Field<Integer> field1() {
        return Livre.LIVRE.ID;
    }

    @Override
    public Field<String> field2() {
        return Livre.LIVRE.TITRE;
    }

    @Override
    public Field<Integer> field3() {
        return Livre.LIVRE.NUMEDITION;
    }

    @Override
    public Field<String> field4() {
        return Livre.LIVRE.DATEAPPARITION;
    }

    @Override
    public Field<Integer> field5() {
        return Livre.LIVRE.STOCK;
    }

    @Override
    public Integer component1() {
        return getId();
    }

    @Override
    public String component2() {
        return getTitre();
    }

    @Override
    public Integer component3() {
        return getNumedition();
    }

    @Override
    public String component4() {
        return getDateapparition();
    }

    @Override
    public Integer component5() {
        return getStock();
    }

    @Override
    public Integer value1() {
        return getId();
    }

    @Override
    public String value2() {
        return getTitre();
    }

    @Override
    public Integer value3() {
        return getNumedition();
    }

    @Override
    public String value4() {
        return getDateapparition();
    }

    @Override
    public Integer value5() {
        return getStock();
    }

    @Override
    public LivreRecord value1(Integer value) {
        setId(value);
        return this;
    }

    @Override
    public LivreRecord value2(String value) {
        setTitre(value);
        return this;
    }

    @Override
    public LivreRecord value3(Integer value) {
        setNumedition(value);
        return this;
    }

    @Override
    public LivreRecord value4(String value) {
        setDateapparition(value);
        return this;
    }

    @Override
    public LivreRecord value5(Integer value) {
        setStock(value);
        return this;
    }

    @Override
    public LivreRecord values(Integer value1, String value2, Integer value3, String value4, Integer value5) {
        value1(value1);
        value2(value2);
        value3(value3);
        value4(value4);
        value5(value5);
        return this;
    }

    // -------------------------------------------------------------------------
    // Constructors
    // -------------------------------------------------------------------------

    /**
     * Create a detached LivreRecord
     */
    public LivreRecord() {
        super(Livre.LIVRE);
    }

    /**
     * Create a detached, initialised LivreRecord
     */
    public LivreRecord(Integer id, String titre, Integer numedition, String dateapparition, Integer stock) {
        super(Livre.LIVRE);

        set(0, id);
        set(1, titre);
        set(2, numedition);
        set(3, dateapparition);
        set(4, stock);
    }
}
