package Vues;

public class CSVVue {
    public static String getLink(int test){
        if ((test == 1))
            vue.print("\nVeuiller entrer le chemain complet du fichier(.csv) : ");
        else
            vue.print("\nVeuiller entrer le chemain complet ou vous voulez mettre le fichier : ");
        return vue.read().next();
    }
    public static int getTable(){
        vue.print("\nSi le fichier contient des etudiants tapez 1, Si le fichier contient des livres tapez 2\n\t Votre choix : ");
        return vue.read().nextInt();
    }
}
