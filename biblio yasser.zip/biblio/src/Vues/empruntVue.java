package Vues;
import Controllers.etudiantController;
import Controllers.livreController;

public class empruntVue {
    public static String[] emprunt(){
        String[] tab = new String[2];
        livreController.getAll(); vue.print("Entrer L'ID du livre : "); tab[0] = vue.read().next();
        etudiantController.getAll(); vue.print("Entrer Le CIN d'étudiant : "); tab[1] = vue.read().next();
        return tab;
    }
    public static String remettre(){
        etudiantController.getAll(); vue.print("Entrer Le CIN d'étudiant : ");
        return vue.read().next();
    }
    public static int remettre1(){
        livreController.getAll(); vue.print("Entrer L'ID du livre : ");
        return vue.read().nextInt();
    }
}
