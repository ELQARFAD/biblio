package Vues;
import Models.generated.tables.records.EtudiantRecord;

public class etudiantVue {
    public static int menuetudiant(){
        vue.print("\n***************** Gestion des étudiants *********************\n\n\t\t\t\t1 - Listes les étudiants\n\t\t\t\t2 - Ajouter un étudiant\n\t\t\t\t3 - Modifier un étudiant\n\t\t\t\t4 - Supprimer un étudiant\n\n\t\tVeuillez entrer votre choix : ");
        return vue.read().nextInt();
    }
    public static String toString(EtudiantRecord e){ return "CIN : "+e.get("cin")+"\n\t\tNom Prénom : "+e.get("nom")+" "+e.get("prenom")+"\t\tFiliére    : "+e.get("filiere")+"\n"; }
    public static String[] insert(){
        String[] tab = new String[4];
        vue.print("Nouveau Etudiant\n\tCIN : "); tab[0] = vue.read().next();
        vue.print("\tNom : "); tab[1] = vue.read().next();
        vue.print("\tPrénom  : "); tab[2] = vue.read().next();
        vue.print("\tFilière : "); tab[3] = vue.read().next();
        return tab;
    }
    public static String[] update(){
        String[] tab = new String[4];
        vue.print("Entrer le CIN d'étudiant'e que vous vouler modifier : "); tab[0] = vue.read().next();
        vue.print("Nouveaux valeurs\n\tNom : "); tab[1] = vue.read().next();
        vue.print("\tPrenom  : "); tab[2] = vue.read().next();
        vue.print("\tFilière : "); tab[3] = vue.read().next();
        return tab;
    }
    public static String delete(){
        vue.printe("Entrer le CIN d'étudiant que vous vouler supprimer : ");
        return vue.read().next();
    }
}
