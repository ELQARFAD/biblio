package Vues;
import Models.generated.tables.records.LivreRecord;

public class livreVue {
    public static int menulivre(){
        vue.print("\n***************** Gestion des livres *********************\n\n\t\t\t\t1 - Listes les livres\n\t\t\t\t2 - Alimenter le stockd'un livre\n\t\t\t\t3 - Ajouter un livre\n\t\t\t\t4 - Modifier un livre\n\t\t\t\t5 - Supprimer un livre\n\n\t\tVeuillez entrer votre choix : ");
        return vue.read().nextInt();
    }
    public static String toString(LivreRecord l){ return "ID : "+l.get("id")+"\n\t\tTitre   : "+l.get("titre")+"\t\t\tDate : "+l.get("dateApparition")+"\t\tEdition : "+l.get("numEdition")+"\t\t\tStock : "+l.get("stock")+"\n"; }
    public static int[] updateStock(){
        int[] tab = new int[2];
        vue.print("Entrer l'ID du livre que vous voulez alimenter : "); tab[0] = vue.read().nextInt();
        vue.print("Enter le Valeur : "); tab[1] = vue.read().nextInt();
        return tab;
    }
    public static String[] insert(){
        String[] tab = new String[4];
        vue.print("Nouveau livre\n\tTitre : "); tab[0] = vue.read().next();
        vue.print("\tNumero d'édition : "); tab[1] = vue.read().next();
        vue.print("\tDate d'apparition : "); tab[2] = vue.read().next();
        vue.print("\tStock : "); tab[3] = vue.read().next();
        return tab;
    }
    public static String[] update(){
        String[] tab = new String[5];
        vue.print("Entrer l'ID du livre que vous vouler modifier : "); tab[0] = vue.read().next();
        vue.print("Nouveaux valeurs\n\tTitre : "); tab[1] = vue.read().next();
        vue.print("\tNumero d'édition : "); tab[2] = vue.read().next();
        vue.print("\tDate d'apparition : "); tab[3] = vue.read().next();
        vue.print("\tStock : "); tab[3] = vue.read().next();
        return tab;
    }
    public static int delete(){
        vue.printe("Entrer l'ID du livre que vous vouler supprimer : ");
        return vue.read().nextInt();
    }
}
