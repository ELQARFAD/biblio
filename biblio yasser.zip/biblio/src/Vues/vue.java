package Vues;
import java.util.Scanner;

public class vue {
    private vue(){ }
    public static void printe(String s){ System.err.print(s); }
    public static void print(String s){ System.out.print(s); }
    public static void NV(){ print("Choix non Valide."); }
    public static void res(){ print("Tapez 0 pour revenir au menu => "); vue.read().nextInt();}
    public static Scanner read(){ return new Scanner(System.in); }
    public static String success(){ return "Bien effectuer.\n";}
    public static int menu(){
        print("***************** Gestion bibliothéque *********************\n\n\t\t\t\t1 - Gérer les livres" +
                "\n\t\t\t\t2 - Gérer les étudiants\n\t\t\t\t3 - Emprunter un livre\n\t\t\t\t4 - Remettre un livre" +
                "\n\t\t\t\t5 - Charger de CSV\n\t\t\t\t6 - Stocker en CSV\n\n\t\tVeuillez entrer votre choix : ");
        return read().nextInt();
    }
}
