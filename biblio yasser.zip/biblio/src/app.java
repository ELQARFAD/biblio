import Controllers.*;
import Vues.vue;

public class app {
    public static void main(String args[]){
        System.err.close();
        System.setErr(System.out);
        System.getProperties().setProperty("org.jooq.no-logo", "true");
        index();
    }
    private static void index(){
        int choix = vue.menu();
        switch (choix){
            case 1: livreController.menulivre();break;
            case 2: etudiantController.menuetudiant();break;
            case 3: empruntController.emprunter();break;
            case 4: empruntController.remettre();break;
            case 5: csvContorller.loadCSV();break;
            case 6: csvContorller.saveCSV();break;
            default: vue.NV();
        }index();
    }
}
